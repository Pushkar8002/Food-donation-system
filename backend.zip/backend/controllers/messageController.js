const Message = require('../models/Message');

exports.getConversation = async (req, res) => {
  try {
    const otherId = req.params.userId;
    const messages = await Message.find({
      $or: [
        { sender: req.userId, recipient: otherId },
        { sender: otherId, recipient: req.userId },
      ],
    }).sort({ createdAt: 1 });

    await Message.updateMany(
      { sender: otherId, recipient: req.userId, read: false },
      { $set: { read: true } }
    );

    res.json({ messages });
  } catch (err) {
    res.status(500).json({ message: 'Failed to load conversation', error: err.message });
  }
};

exports.sendMessage = async (req, res) => {
  try {
    const { recipientId, text } = req.body;
    if (!recipientId || !text) {
      return res.status(400).json({ message: 'recipientId and text are required' });
    }

    const message = await Message.create({ sender: req.userId, recipient: recipientId, text });

    // Emit over Socket.io if the recipient is connected (see server.js io setup)
    const io = req.app.get('io');
    const onlineUsers = req.app.get('onlineUsers');
    const socketId = onlineUsers?.get(recipientId);
    if (io && socketId) {
      io.to(socketId).emit('newMessage', message);
    }

    res.status(201).json({ message });
  } catch (err) {
    res.status(500).json({ message: 'Failed to send message', error: err.message });
  }
};

exports.listConversationPartners = async (req, res) => {
  try {
    const messages = await Message.find({
      $or: [{ sender: req.userId }, { recipient: req.userId }],
    })
      .sort({ createdAt: -1 })
      .populate('sender', 'name avatarUrl')
      .populate('recipient', 'name avatarUrl');

    const seen = new Map();
    for (const m of messages) {
      const other = m.sender._id.toString() === req.userId ? m.recipient : m.sender;
      if (!seen.has(other._id.toString())) {
        seen.set(other._id.toString(), { user: other, lastMessage: m });
      }
    }

    res.json({ conversations: Array.from(seen.values()) });
  } catch (err) {
    res.status(500).json({ message: 'Failed to list conversations', error: err.message });
  }
};
