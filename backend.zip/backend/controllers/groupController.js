const Group = require('../models/Group');
const User = require('../models/User');

exports.createGroup = async (req, res) => {
  try {
    const { name, description, category, coverImageUrl, tags } = req.body;
    if (!name || !category) {
      return res.status(400).json({ message: 'Name and category are required' });
    }

    const group = await Group.create({
      name,
      description,
      category,
      coverImageUrl,
      tags,
      creator: req.userId,
      members: [req.userId],
    });

    await User.findByIdAndUpdate(req.userId, { $addToSet: { groups: group._id } });

    res.status(201).json({ group });
  } catch (err) {
    res.status(500).json({ message: 'Failed to create group', error: err.message });
  }
};

exports.listGroups = async (req, res) => {
  try {
    const { category, search } = req.query;
    const filter = {};
    if (category) filter.category = category;
    if (search) filter.name = { $regex: search, $options: 'i' };

    const groups = await Group.find(filter)
      .select('name description category coverImageUrl members')
      .limit(50);
    res.json({ groups });
  } catch (err) {
    res.status(500).json({ message: 'Failed to list groups', error: err.message });
  }
};

exports.getGroup = async (req, res) => {
  try {
    const group = await Group.findById(req.params.id).populate('members', 'name avatarUrl');
    if (!group) return res.status(404).json({ message: 'Group not found' });
    res.json({ group });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch group', error: err.message });
  }
};

exports.joinGroup = async (req, res) => {
  try {
    const group = await Group.findById(req.params.id);
    if (!group) return res.status(404).json({ message: 'Group not found' });

    if (!group.members.includes(req.userId)) {
      group.members.push(req.userId);
      await group.save();
      await User.findByIdAndUpdate(req.userId, { $addToSet: { groups: group._id } });
    }

    res.json({ message: 'Joined group' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to join group', error: err.message });
  }
};

exports.leaveGroup = async (req, res) => {
  try {
    const group = await Group.findById(req.params.id);
    if (!group) return res.status(404).json({ message: 'Group not found' });

    group.members = group.members.filter((id) => id.toString() !== req.userId);
    await group.save();
    await User.findByIdAndUpdate(req.userId, { $pull: { groups: group._id } });

    res.json({ message: 'Left group' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to leave group', error: err.message });
  }
};

// Recommend groups matching the user's stated interests that they haven't joined
exports.recommendGroups = async (req, res) => {
  try {
    const me = await User.findById(req.userId);
    if (!me) return res.status(404).json({ message: 'User not found' });

    const groups = await Group.find({
      _id: { $nin: me.groups },
      $or: [
        { category: { $in: me.interests } },
        { tags: { $in: me.interests } },
      ],
    })
      .select('name description category coverImageUrl members')
      .limit(10);

    res.json({ recommendations: groups });
  } catch (err) {
    res.status(500).json({ message: 'Failed to get recommendations', error: err.message });
  }
};
