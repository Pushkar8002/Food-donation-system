const User = require('../models/User');

exports.getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.params.id)
      .select('-password')
      .populate('groups', 'name category');
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json({ user });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch profile', error: err.message });
  }
};

exports.updateProfile = async (req, res) => {
  try {
    const { name, bio, avatarUrl, quote, mobileNumber, theme, interests } = req.body;
    const user = await User.findById(req.userId);
    if (!user) return res.status(404).json({ message: 'User not found' });

    if (name !== undefined) user.name = name;
    if (bio !== undefined) user.bio = bio;
    if (avatarUrl !== undefined) user.avatarUrl = avatarUrl;
    if (quote !== undefined) user.quote = quote;
    if (mobileNumber !== undefined) {
      const normalizedMobileNumber = mobileNumber.replace(/[\s-]/g, '');
      if (normalizedMobileNumber && !/^(?:\+91|91)?[6-9]\d{9}$/.test(normalizedMobileNumber)) {
        return res.status(400).json({ message: 'Enter a valid Indian mobile number' });
      }
      user.mobileNumber = mobileNumber;
    }
    if (theme !== undefined) user.theme = theme;
    if (interests !== undefined) user.interests = interests;

    await user.save();
    res.json({ user: user.toSafeObject() });
  } catch (err) {
    res.status(500).json({ message: 'Failed to update profile', error: err.message });
  }
};

exports.followUser = async (req, res) => {
  try {
    const targetId = req.params.id;
    if (targetId === req.userId) {
      return res.status(400).json({ message: "You can't follow yourself" });
    }

    const [me, target] = await Promise.all([
      User.findById(req.userId),
      User.findById(targetId),
    ]);
    if (!target) return res.status(404).json({ message: 'User not found' });

    if (!me.following.includes(targetId)) {
      me.following.push(targetId);
      target.followers.push(req.userId);
      await Promise.all([me.save(), target.save()]);
    }

    res.json({ message: 'Followed successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to follow user', error: err.message });
  }
};

exports.unfollowUser = async (req, res) => {
  try {
    const targetId = req.params.id;
    const [me, target] = await Promise.all([
      User.findById(req.userId),
      User.findById(targetId),
    ]);
    if (!target) return res.status(404).json({ message: 'User not found' });

    me.following = me.following.filter((id) => id.toString() !== targetId);
    target.followers = target.followers.filter((id) => id.toString() !== req.userId);
    await Promise.all([me.save(), target.save()]);

    res.json({ message: 'Unfollowed successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to unfollow user', error: err.message });
  }
};

// Simple member-matching suggestion: users sharing the most interests, excluding self and already-followed
exports.suggestConnections = async (req, res) => {
  try {
    const me = await User.findById(req.userId);
    if (!me) return res.status(404).json({ message: 'User not found' });

    const candidates = await User.find({
      _id: { $ne: me._id, $nin: me.following },
      interests: { $in: me.interests },
    })
      .select('name avatarUrl interests')
      .limit(20);

    const scored = candidates
      .map((c) => ({
        user: c,
        sharedInterests: c.interests.filter((i) => me.interests.includes(i)).length,
      }))
      .sort((a, b) => b.sharedInterests - a.sharedInterests)
      .slice(0, 10);

    res.json({ suggestions: scored });
  } catch (err) {
    res.status(500).json({ message: 'Failed to get suggestions', error: err.message });
  }
};
