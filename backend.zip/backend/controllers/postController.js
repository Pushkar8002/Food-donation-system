const Post = require('../models/Post');
const User = require('../models/User');

exports.createPost = async (req, res) => {
  try {
    const { content, imageUrl, group } = req.body;
    if (!content) return res.status(400).json({ message: 'Content is required' });

    const post = await Post.create({ author: req.userId, content, imageUrl, group: group || null });
    const populated = await post.populate('author', 'name avatarUrl');
    res.status(201).json({ post: populated });
  } catch (err) {
    res.status(500).json({ message: 'Failed to create post', error: err.message });
  }
};

// Feed ranking: recency-weighted engagement score.
// score = (reactions*1 + comments*2) / (hoursSincePosted + 2)^1.5
const computeRank = (post) => {
  const hours = (Date.now() - new Date(post.createdAt).getTime()) / 36e5;
  const engagement = post.reactions.length * 1 + post.comments.length * 2;
  return engagement / Math.pow(hours + 2, 1.5);
};

exports.getFeed = async (req, res) => {
  try {
    const me = await User.findById(req.userId);
    const authorIds = [...me.following, me._id];

    const posts = await Post.find({
      $or: [{ author: { $in: authorIds } }, { group: { $in: me.groups } }],
    })
      .populate('author', 'name avatarUrl')
      .populate('group', 'name')
      .sort({ createdAt: -1 })
      .limit(200)
      .lean();

    const ranked = posts
      .map((p) => ({ ...p, engagementScore: computeRank(p) }))
      .sort((a, b) => b.engagementScore - a.engagementScore);

    res.json({ feed: ranked });
  } catch (err) {
    res.status(500).json({ message: 'Failed to load feed', error: err.message });
  }
};

exports.reactToPost = async (req, res) => {
  try {
    const { type = 'like' } = req.body;
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: 'Post not found' });

    const existing = post.reactions.find((r) => r.user.toString() === req.userId);
    if (existing) {
      existing.type = type;
    } else {
      post.reactions.push({ user: req.userId, type });
    }
    await post.save();
    res.json({ reactions: post.reactions });
  } catch (err) {
    res.status(500).json({ message: 'Failed to react', error: err.message });
  }
};

exports.commentOnPost = async (req, res) => {
  try {
    const { text } = req.body;
    if (!text) return res.status(400).json({ message: 'Comment text is required' });

    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: 'Post not found' });

    post.comments.push({ author: req.userId, text });
    await post.save();
    const populated = await post.populate('comments.author', 'name avatarUrl');
    res.status(201).json({ comments: populated.comments });
  } catch (err) {
    res.status(500).json({ message: 'Failed to comment', error: err.message });
  }
};

exports.deletePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: 'Post not found' });
    if (post.author.toString() !== req.userId) {
      return res.status(403).json({ message: 'Not authorized to delete this post' });
    }
    await post.deleteOne();
    res.json({ message: 'Post deleted' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete post', error: err.message });
  }
};
