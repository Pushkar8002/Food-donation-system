const mongoose = require('mongoose');
const Donation = require('../models/Donation');
const dietaryOptions = ['Vegetarian', 'Vegan', 'Lactose-free', 'Gluten-free', 'Dairy-free'];
const allergenOptions = ['Wheat', 'Dairy', 'Eggs', 'Soy', 'Peanuts', 'Tree nuts', 'Sesame', 'Fish', 'Shellfish'];

const populatePeople = (query) => query
  .populate('donor', 'name avatarUrl')
  .populate('claimedBy', 'name avatarUrl');

exports.listDonations = async (req, res) => {
  try {
    const mine = req.query.mine === 'true';
    const filter = mine
      ? { $or: [{ donor: req.userId }, { claimedBy: req.userId }] }
      : { status: 'available', availableUntil: { $gt: new Date() } };
    const donations = await populatePeople(Donation.find(filter).sort({ createdAt: -1 })).lean();

    const visibleDonations = donations.map((donation) => {
      const isInvolved = donation.donor?._id.toString() === req.userId
        || donation.claimedBy?._id.toString() === req.userId;
      if (!isInvolved) delete donation.pickupInstructions;
      return donation;
    });

    res.json({ donations: visibleDonations });
  } catch (err) {
    res.status(500).json({ message: 'Failed to load food offers', error: err.message });
  }
};

exports.createDonation = async (req, res) => {
  try {
    const {
      foodName,
      description,
      donorType,
      quantity,
      servings,
      pickupLocation,
      pickupInstructions,
      availableUntil,
      dietaryTags = [],
      allergens = [],
    } = req.body;
    const expiry = new Date(availableUntil);
    const servingCount = Number(servings);

    if (!foodName?.trim() || !quantity?.trim() || !pickupLocation?.trim() || !availableUntil) {
      return res.status(400).json({ message: 'Food, quantity, pickup location, and pickup deadline are required' });
    }
    if (!Number.isInteger(servingCount) || servingCount < 1) {
      return res.status(400).json({ message: 'Servings must be a whole number of at least 1' });
    }
    if (!Array.isArray(dietaryTags) || dietaryTags.some((tag) => !dietaryOptions.includes(tag))) {
      return res.status(400).json({ message: 'One or more dietary labels are invalid' });
    }
    if (!Array.isArray(allergens) || allergens.some((allergen) => !allergenOptions.includes(allergen))) {
      return res.status(400).json({ message: 'One or more allergen labels are invalid' });
    }
    if (Number.isNaN(expiry.getTime()) || expiry <= new Date()) {
      return res.status(400).json({ message: 'Pickup deadline must be in the future' });
    }

    const donation = await Donation.create({
      donor: req.userId,
      foodName,
      description,
      donorType,
      quantity,
      servings: servingCount,
      dietaryTags,
      allergens,
      pickupLocation,
      pickupInstructions,
      availableUntil: expiry,
    });
    await donation.populate([
      { path: 'donor', select: 'name avatarUrl' },
      { path: 'claimedBy', select: 'name avatarUrl' },
    ]);
    res.status(201).json({ donation });
  } catch (err) {
    res.status(500).json({ message: 'Failed to publish food offer', error: err.message });
  }
};

exports.updateDonation = async (req, res) => {
  try {
    const {
      foodName,
      description,
      donorType,
      quantity,
      servings,
      pickupLocation,
      pickupInstructions,
      availableUntil,
      dietaryTags = [],
      allergens = [],
    } = req.body;
    const expiry = new Date(availableUntil);
    const servingCount = Number(servings);

    if (!foodName?.trim() || !quantity?.trim() || !pickupLocation?.trim() || !availableUntil) {
      return res.status(400).json({ message: 'Food, quantity, pickup location, and pickup deadline are required' });
    }
    if (!Number.isInteger(servingCount) || servingCount < 1) {
      return res.status(400).json({ message: 'Servings must be a whole number of at least 1' });
    }
    if (!Array.isArray(dietaryTags) || dietaryTags.some((tag) => !dietaryOptions.includes(tag))) {
      return res.status(400).json({ message: 'One or more dietary labels are invalid' });
    }
    if (!Array.isArray(allergens) || allergens.some((allergen) => !allergenOptions.includes(allergen))) {
      return res.status(400).json({ message: 'One or more allergen labels are invalid' });
    }
    if (Number.isNaN(expiry.getTime()) || expiry <= new Date()) {
      return res.status(400).json({ message: 'Pickup deadline must be in the future' });
    }
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(404).json({ message: 'Food offer not found' });
    }

    const donation = await Donation.findOneAndUpdate(
      { _id: req.params.id, donor: req.userId, status: 'available' },
      {
        $set: {
          foodName,
          description,
          donorType,
          quantity,
          servings: servingCount,
          pickupLocation,
          pickupInstructions,
          availableUntil: expiry,
          dietaryTags,
          allergens,
        },
      },
      { new: true, runValidators: true }
    );
    if (!donation) {
      const existing = await Donation.findById(req.params.id).select('donor status');
      if (!existing) return res.status(404).json({ message: 'Food offer not found' });
      if (existing.donor.toString() !== req.userId) {
        return res.status(403).json({ message: 'Only the donor can edit this food offer' });
      }
      return res.status(409).json({ message: 'Only available food offers can be edited' });
    }

    await donation.populate([
      { path: 'donor', select: 'name avatarUrl' },
      { path: 'claimedBy', select: 'name avatarUrl' },
    ]);
    res.json({ donation });
  } catch (err) {
    res.status(500).json({ message: 'Failed to edit food offer', error: err.message });
  }
};

exports.claimDonation = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(404).json({ message: 'Food offer not found' });
    }

    const donation = await populatePeople(Donation.findOneAndUpdate(
      {
        _id: req.params.id,
        donor: { $ne: req.userId },
        status: 'available',
        availableUntil: { $gt: new Date() },
      },
      { $set: { status: 'claimed', claimedBy: req.userId, claimedAt: new Date() } },
      { new: true, runValidators: true }
    ));
    if (!donation) {
      return res.status(409).json({ message: 'This food offer is no longer available' });
    }

    res.json({ donation });
  } catch (err) {
    res.status(500).json({ message: 'Failed to claim food offer', error: err.message });
  }
};

exports.releaseDonation = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(404).json({ message: 'Food offer not found' });
    }

    const donation = await populatePeople(Donation.findOneAndUpdate(
      { _id: req.params.id, claimedBy: req.userId, status: 'claimed' },
      { $set: { status: 'available', claimedBy: null, claimedAt: null } },
      { new: true, runValidators: true }
    ));
    if (!donation) {
      return res.status(409).json({ message: 'This claim could not be released' });
    }

    res.json({ donation });
  } catch (err) {
    res.status(500).json({ message: 'Failed to release food offer', error: err.message });
  }
};

exports.updateDonationStatus = async (req, res) => {
  try {
    const { status } = req.body;
    if (!['collected', 'cancelled'].includes(status)) {
      return res.status(400).json({ message: 'Status must be collected or cancelled' });
    }
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(404).json({ message: 'Food offer not found' });
    }

    const expectedStatus = status === 'collected' ? 'claimed' : 'available';
    const changes = status === 'collected'
      ? { $set: { status, collectedAt: new Date() } }
      : { $set: { status } };
    const donation = await populatePeople(Donation.findOneAndUpdate(
      { _id: req.params.id, donor: req.userId, status: expectedStatus },
      changes,
      { new: true, runValidators: true }
    ));
    if (!donation) {
      const existing = await Donation.findById(req.params.id).select('donor status');
      if (!existing) return res.status(404).json({ message: 'Food offer not found' });
      if (existing.donor.toString() !== req.userId) {
        return res.status(403).json({ message: 'Only the donor can update this food offer' });
      }
      return res.status(409).json({ message: 'This food offer cannot be updated from its current status' });
    }

    res.json({ donation });
  } catch (err) {
    res.status(500).json({ message: 'Failed to update food offer', error: err.message });
  }
};

exports.confirmDonationCollected = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(404).json({ message: 'Food offer not found' });
    }

    const donation = await populatePeople(Donation.findOneAndUpdate(
      { _id: req.params.id, claimedBy: req.userId, status: 'claimed' },
      { $set: { status: 'collected', collectedAt: new Date() } },
      { new: true, runValidators: true }
    ));
    if (!donation) {
      const existing = await Donation.findById(req.params.id).select('claimedBy status');
      if (!existing) return res.status(404).json({ message: 'Food offer not found' });
      if (existing.claimedBy?.toString() !== req.userId) {
        return res.status(403).json({ message: 'Only the recipient who claimed this food can confirm collection' });
      }
      return res.status(409).json({ message: 'This food offer has already been updated' });
    }

    res.json({ donation });
  } catch (err) {
    res.status(500).json({ message: 'Failed to confirm collection', error: err.message });
  }
};
