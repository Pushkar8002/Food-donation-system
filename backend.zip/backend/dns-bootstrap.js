const dns = require('node:dns');
const { execFileSync } = require('node:child_process');

if (process.platform === 'win32' && dns.getServers().includes('127.0.0.1')) {
  try {
    const servers = execFileSync('powershell.exe', [
      '-NoLogo',
      '-NoProfile',
      '-NonInteractive',
      '-Command',
      'Get-DnsClientServerAddress -AddressFamily IPv4 | Where-Object { $_.ServerAddresses.Count -gt 0 } | ForEach-Object { $_.ServerAddresses }',
    ], { encoding: 'utf8' })
      .split(/\r?\n/)
      .map((server) => server.trim())
      .filter(Boolean);

    if (servers.length > 0) dns.setServers(servers);
  } catch {
  }
}