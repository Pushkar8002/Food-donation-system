const mongoose = require('mongoose');

const donationSchema = new mongoose.Schema(
  {
    donor: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    foodName: { type: String, required: true, trim: true, maxlength: 120 },
    description: { type: String, trim: true, default: '', maxlength: 1000 },
    donorType: {
      type: String,
      enum: ['family', 'hotel', 'restaurant', 'community kitchen', 'other'],
      default: 'family',
    },
    quantity: { type: String, required: true, trim: true, maxlength: 80 },
    servings: { type: Number, required: true, min: 1 },
    dietaryTags: {
      type: [{ type: String, enum: ['Vegetarian', 'Vegan', 'Lactose-free', 'Gluten-free', 'Dairy-free'] }],
      default: [],
    },
    allergens: {
      type: [{ type: String, enum: ['Wheat', 'Dairy', 'Eggs', 'Soy', 'Peanuts', 'Tree nuts', 'Sesame', 'Fish', 'Shellfish'] }],
      default: [],
    },
    pickupLocation: { type: String, required: true, trim: true, maxlength: 200 },
    pickupInstructions: { type: String, trim: true, default: '', maxlength: 500 },
    availableUntil: { type: Date, required: true, index: true },
    status: {
      type: String,
      enum: ['available', 'claimed', 'collected', 'cancelled'],
      default: 'available',
      index: true,
    },
    claimedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    claimedAt: { type: Date, default: null },
    collectedAt: { type: Date, default: null },
  },
  { timestamps: true }
);

donationSchema.index({ status: 1, availableUntil: 1, createdAt: -1 });

module.exports = mongoose.model('Donation', donationSchema);
