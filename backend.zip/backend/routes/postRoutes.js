const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const {
  createPost,
  getFeed,
  reactToPost,
  commentOnPost,
  deletePost,
} = require('../controllers/postController');

router.get('/feed', auth, getFeed);
router.post('/', auth, createPost);
router.post('/:id/react', auth, reactToPost);
router.post('/:id/comment', auth, commentOnPost);
router.delete('/:id', auth, deletePost);

module.exports = router;
