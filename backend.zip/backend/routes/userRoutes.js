const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const {
  getProfile,
  updateProfile,
  followUser,
  unfollowUser,
  suggestConnections,
} = require('../controllers/userController');

router.get('/suggestions', auth, suggestConnections);
router.get('/:id', getProfile);
router.put('/me', auth, updateProfile);
router.post('/:id/follow', auth, followUser);
router.post('/:id/unfollow', auth, unfollowUser);

module.exports = router;
