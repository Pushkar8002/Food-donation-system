const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const {
  createGroup,
  listGroups,
  getGroup,
  joinGroup,
  leaveGroup,
  recommendGroups,
} = require('../controllers/groupController');

router.get('/recommendations', auth, recommendGroups);
router.get('/', listGroups);
router.post('/', auth, createGroup);
router.get('/:id', getGroup);
router.post('/:id/join', auth, joinGroup);
router.post('/:id/leave', auth, leaveGroup);

module.exports = router;
