const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const {
  getConversation,
  sendMessage,
  listConversationPartners,
} = require('../controllers/messageController');

router.get('/', auth, listConversationPartners);
router.get('/:userId', auth, getConversation);
router.post('/', auth, sendMessage);

module.exports = router;
