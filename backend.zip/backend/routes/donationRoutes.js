const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const {
  listDonations,
  createDonation,
  updateDonation,
  claimDonation,
  releaseDonation,
  updateDonationStatus,
  confirmDonationCollected,
} = require('../controllers/donationController');

router.use(auth);
router.get('/', listDonations);
router.post('/', createDonation);
router.put('/:id', updateDonation);
router.post('/:id/claim', claimDonation);
router.post('/:id/release', releaseDonation);
router.post('/:id/confirm-collected', confirmDonationCollected);
router.patch('/:id/status', updateDonationStatus);

module.exports = router;
